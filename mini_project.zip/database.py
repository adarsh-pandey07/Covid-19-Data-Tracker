import sqlite3


# database
def table() :
    conn = sqlite3.connect('no_of_case.db')

    c = conn.cursor()
    # c.execute("""CREATE TABLE info (
    #             text text,
    #             count integer
    #             )""")
    # cases = [('Active Cases', '39834'),
    #          ('Cured/Discharged', '17846'),
    #          ('Deaths', '1981'),
    #          ('Migrated', '1')]
    # c.executemany("INSERT INTO info VALUES (?,?)", cases)
    # conn.commit()

    for row in c.execute('SELECT * FROM info '):
        print(row)

    print(" \n \nTable Successfully Created")
    conn.close()


table()
